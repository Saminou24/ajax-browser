<div id='footer'>
	<a href="http://jigsaw.w3.org/css-validator/check?uri=referer">
		<img
			src="./_files/images/valid_css_80x15.png"
			alt="Valid CSS 2.1" title="Valid CSS 2.1" />
		</a>
	<a href="http://validator.w3.org/check?uri=referer">
		<img
			src="./_files/images/valid_xhtml_80x15.png"
			alt="Valid XHTML 1.0 Strict" title="Valid XHTML 1.0 Strict" />
	</a>
	<a href="http://fr.wikipedia.org/wiki/Accessibilit%E9_du_Web#Recommandations_pour_le_contenu">
		<img
			src="./_files/images/valid_wai-aa_80x15.png"
			alt="Accesibilité niveau AA" />
	</a>
</div>