<!--MENU BLOCK-->
<h2 class='h'>Menu de navigation</h2>
	<ul id='menu' title='menu de navigation'>
			<li class='<?php  status('acceuil');?> menu'><a href='?p=acceuil' title='Accueil' accesskey='A'>Accueil</a></li>
		<li class='<?php  status('recherche');?> menu'><a href='?p=recherche' title='Recherche' accesskey='E'>Recherche</a> </li>
		<li class='<?php  status('contact');?> menu'><a href='?p=contact' title='Contacts' accesskey='F'>Contacts</a> </li>
	</ul>
