<h1>Page d'Acceuil</h1>
<h2>Bienvenue&thinsp;!</h2>
<div>
	<div id='banner'>
		<div class='header'>Projets étudiants</div>
	</div>
	<p>Vous trouverez sur ce site les <em>projets transpromotions</em> et <em>transdisciplinaires</em> menés par les étudiants de l'Institut de Cognitique.<br/>
	Il a été réalisé dans le cadre de l'unité d'enseignement «&thinsp;Outils de communication&thinsp;» du Professeur E. <span class='aut'>Clermont</span>, par D. <span class='aut'>Graeff</span> et Y. <span class='aut'>Medoukali</span>.</p>
	<dl>
		<dt>Un <span class='b'>projet transdisciplinaire</span>&thinsp;:</dt>
			<dd>est généralement donné par un tuteur à trois élèves d'une même promotion (1<sup>re</sup> ou 2<sup>e</sup> année). Il se déroule tout au long de l'année universitaire et fait intervenir plusieurs disciplines.</dd>
		<dt>Un <span class='b'>projet transpromotion</span>&thinsp;:</dt>
			<dd>est généralement proposé par trois élèves en 2<sup>e</sup> année, et mené avec trois 1<sup>er</sup> années sur un semestre.</dd>
	</dl>
</div>


