<h1>Page de Contacts</h1>
<h2>Informations de contact</h2>
<div id='contact'>
	<p>Pour avoir des informations sur l'Institut de Cognitique, visitez le site de l'<a href="http://www.idc-bordeaux.fr/">Institut de Cognitique</a>. Pour tout envoi de documents officiel, référez-vous à l'adresse suivante&thinsp;:</p>
	<dl id='adrs'>
		<dt>Adresse postale de l'<acronym title='Institut de Cognitique'>IdC</acronym>&thinsp;:</dt>
			<dd>Université Victor Segalen Bordeaux 2</dd>
			<dd>Bâtiment 2&thinsp;A - Rez de Jardin</dd>
			<dd>146, rue Léo Saignat - Case 40</dd>
			<dd>33076 Bordeaux <span class='aut'>cedex</span> </dd>
	</dl>
</div>
