-- phpMyAdmin SQL Dump
-- version 2.11.3deb1ubuntu1.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 06 Décembre 2008 à 23:52
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.4-2ubuntu5.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `projet`
--
-- CREATE DATABASE `projet`  DEFAULT CHARACTER SET Utf8 COLLATE Utf8_general_ci;
-- USE `projet`;
CREATE DATABASE `idc`  DEFAULT CHARACTER SET Utf8 COLLATE Utf8_general_ci;
USE `idc`;

-- --------------------------------------------------------

--
-- Structure de la table `encadrant`
-- essayer: ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_unicode_ci si Ã§a marche pas

CREATE TABLE IF NOT EXISTS `encadrant` (
  `id_encadrant` int(11) NOT NULL auto_increment,
  `nom_encadrant` varchar(42) NOT NULL,
  `pren_encadrant` varchar(42) NOT NULL,
  `mail` varchar(42) default NULL,
  `fonction_encadrant` varchar(70) default NULL,
  `no_etablabo_` int(11) default NULL,
  PRIMARY KEY  (`id_encadrant`),
  KEY `no_etablabo_` (`no_etablabo_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `encadrant`
--

INSERT INTO `encadrant` (`id_encadrant`, `nom_encadrant`, `pren_encadrant`, `mail`, `fonction_encadrant`, `no_etablabo_`) VALUES
(1,'','','','',1),
(2, "Oudeyer", "Pierre-Yves", "pierre-yves.oudeyer@inria.fr", "Chercheur", 2);

-- --------------------------------------------------------

--
-- Structure de la table `etablabo`
--

CREATE TABLE IF NOT EXISTS `etablabo` (
  `no_etablabo` int(11) NOT NULL auto_increment,
  `nom_etablabo` varchar(70) NOT NULL,
  `adr_etablabo` longtext,
  `id_univentr_` int(11) NOT NULL,
  PRIMARY KEY  (`no_etablabo`),
  KEY `id_univentr_` (`id_univentr_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `etablabo`
--

INSERT INTO `etablabo` (`no_etablabo`, `nom_etablabo`, `adr_etablabo`, `id_univentr_`) VALUES
(1,'','',1),
(2, "INRIA Bordeaux Sud-Ouest", "Campus universitaire de Talence, Université Bordeaux 1", 2);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE IF NOT EXISTS `etudiant` (
  `no_etud` varchar(11) NOT NULL,
  `nom_etud` varchar(42) NOT NULL,
  `pren_etud` varchar(42) NOT NULL,
  `promo` int(4) NOT NULL,
  `origine_scol` varchar(42) default NULL,
  PRIMARY KEY  (`no_etud`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;

--
-- Contenu de la table `etudiant`
--

INSERT INTO `etudiant` (`no_etud`, `nom_etud`, `pren_etud`, `promo`, `origine_scol`) VALUES
("0299033703J", "Medoukali", "Yassine", 2011, "Prépa MP"),
("11111111111", "Naulin", "Simon", 2042, "Prépa MP"),
("22222222222", "Dupont", "Romain", 2999, "IUT informatique"),
("33333333333", "Buy-Quang", "Paul", 2011, NULL),
("44444444444", "Hirigoyen", "William", 2011, NULL),
("55555555555", "Vovard", "Kévin", 2011, "Prépa"),
("66666666666", "Langlais", "Hugo", 2011, "Prépa MP"),
("77777777777", "Chauvelin", "Camille", 2010, NULL),
("88888888888", "Bonjour", "Henry", 2010, "Prépa MP"),
("987654321dd", "Graeff", "Delphine", 2011, "Licence sciences cognitives"),
("99999999999", "Marchand", "Victorien", 2010, "Prépa PC");

-- --------------------------------------------------------

--
-- Structure de la table `porter_sur`
--

CREATE TABLE IF NOT EXISTS `porter_sur` (
  `id_theme` varchar(42) NOT NULL,
  `no_projet_` int(11) NOT NULL,
  PRIMARY KEY  (`id_theme`,`no_projet_`),
  KEY `no_projet_` (`no_projet_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;

--
-- Contenu de la table `porter_sur`
--

INSERT INTO `porter_sur` (`id_theme`, `no_projet_`) VALUES
("Suppléance", 1),
("Traitement de l'image", 1),
("Communication non-verbale", 2),
("Informatique", 2),
("Robot", 2),
("Informatique", 3),
("Perception auditive", 3),
("Traitement du son", 3),
("Dynamique de groupe", 4),
("Modélisation", 4),
("Systèmes Multi-Agents", 4);

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE IF NOT EXISTS `projet` (
  `no_projet` int(11) NOT NULL auto_increment,
  `type` varchar(42) NOT NULL,
  `annee` varchar(9) NOT NULL,
  `titre` varchar(200) NOT NULL,
  `resume` longtext,
  `descriptif` longtext,
  `chrono` longtext,
  `id_encadrant_` int(11) NOT NULL,
  PRIMARY KEY  (`no_projet`),
  KEY `id_encadrant_` (`id_encadrant_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `projet`
--

INSERT INTO `projet` (`no_projet`, `type`, `annee`, `titre`, `resume`, `descriptif`, `chrono`, `id_encadrant_`) VALUES
(1, "Transpromo", "2008/2009", "Vêtements et accessoires d'aide et de suppléance aux personnes aveugles", "There is a world where witches rule the northern skies, where ice bears are the bravest warriors and where every human is joined with an animal spirit which is as close to hime as his own heart... but this world is dominated by the Magisterium which intends to control the whole humanity, and his greatest threat is a golden compass and the one child destined to possess it...", "Notre projet transpromotion s'intéressait initialement aux vêtements et accessoires électroniques de suppléance à un handicap. Ces systèmes présentent l'avantage d'être continuellement opérationnels. Cependant, ce sujet était bien trop vaste, et pour éclaircir tout cela, il nous fallait axer notre travail sur un handicap en particulier.\r\n\r\nEn nous réunissant, nous avons ainsi décidé de nous intéresser aux personnes aveugles. En effet, l'exploration de différents handicaps ainsi que des technologies de suppléance existantes nous ont mené à cette population, qui ne dispose pas de véritable système électronique pour l'aider à se déplacer dans l'espace.\r\n\r\nUne personne aveugle a les mêmes besoins que tout autre individu, en particulier d'autonomie. En faisant quelques recherches sur Internet, on peut constater qu'il existe un grand nombre de forums où des personnes malvoyantes exposent leur mal-être vis-à-vis de l'aide constante que proposent les gens les entourant, pour se déplacer. Ils affirment pouvoir se déplacer sans aucune aide.\r\nC'est le même mal-être qui hante les aveugles si ce n'est qu'il est plus fort chez eux, car le besoin des autres existe dans un grand nombre de situations, malgré les quelques systèmes qui leur sont proposés.\r\n\r\nAinsi, nous avons pour espoir de venir en aide à ces personnes-là au niveau de leurs déplacements. Pour cela, nous nous sommes penchés sur les technologies existantes et/ou nécessaires à la réalisation d'un vêtement ou d'un accessoire qui leur permettrait de gagner en autonomie tout en étant confortable et simple d'utilisation. En parallèle, nous nous sommes également intéressés à la vie d'une personne aveugle, aux difficultés qui sont présentes dans son quotidien et que nous allons devoir considérer pour le bon déroulement de notre projet. \r\n\r\n", '', 1),
(2, "Transdisciplinaire 1A", "2008/2009", "Interaction homme/robot", "Etude de la communication verbale non verbale Homme/Homme et Homme/robots pour la \r\nrobotique domestique.", "  Les robots d'interaction actuels sont destinés à des personnes qualifiés (non novice) et \r\nleur utilisation reste difficile pour un individu lambda. \r\nDans un futur proche il sera nécessaire de fabriquer des robots « intelligents » capables \r\nde comprendre et de répondre aux langages et comportements humains.\r\n Notre étude consiste à trouver un élément original, et néanmoins important, de la \r\ncommunication homme/homme n'ayant pas à l'heure actuelle été encore intégré dans \r\nl'étude de l'interaction homme/robot. \r\n  Cet élément sera ensuite implémenté dans un robot et expérimenté dans une situation \r\nspécifique donnée.", "15/09 au 05/12 : étude de l'existant sur le non­verbal et les interactions hommes/robots. \r\nSynthèse. Recherches annexes.\r\n10/12: réunion de présentation à nos tuteurs de stage\r\n10 /12 au 05/01: étude de l'aibo et de son langage, remise à niveau en c++ (très proche du \r\nlangage de l'aibo).\r\n05/01 au 02/03: codage de l'aibo, création du programme et du protocole expérimental.\r\n02/03 au 23/03: expérimentation.\r\n23/03 au 17/04: Réalisation du site Internet, facilitée par le Wiki tenu à jour tout au long du \r\nprojet.", 2),
(3, "Transdisciplinaire 1A", "2008/2009", "Audition des animaux", "Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.\r\nCeci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.", "Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.\r\nCeci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.", "Ceci est un test.\r\n\r\nCeci est un test.\r\n\r\nCeci est un test.Ceci est un test.\r\n\r\nCeci est un test.", 1),
(4, "Transpromo", "2008/2009", "Modélisation du comportement de groupe", "Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.", "Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.Ceci est un test.", "Ceci est un test.\r\n\r\nCeci est un test.\r\n\r\nCeci est un test.", 1);

-- --------------------------------------------------------

--
-- Structure de la table `suivre`
--

CREATE TABLE IF NOT EXISTS `suivre` (
  `no_projet_` int(11) NOT NULL,
  `id_tuteur_` int(11) NOT NULL,
  PRIMARY KEY  (`no_projet_`,`id_tuteur_`),
  KEY `id_tuteur_` (`id_tuteur_`),
  KEY `no_projet_` (`no_projet_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;

--
-- Contenu de la table `suivre`
--

INSERT INTO `suivre` (`no_projet_`, `id_tuteur_`) VALUES
(1, 1),
(4, 1),
(2, 2),
(2, 3),
(3, 4);

-- --------------------------------------------------------

--
-- Structure de la table `travailler`
--

CREATE TABLE IF NOT EXISTS `travailler` (
  `no_etud_` varchar(11) NOT NULL,
  `no_projet_` int(11) NOT NULL,
  PRIMARY KEY  (`no_etud_`,`no_projet_`),
  KEY `no_projet_` (`no_projet_`),
  KEY `no_etud_` (`no_etud_`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;

--
-- Contenu de la table `travailler`
--

INSERT INTO `travailler` (`no_etud_`, `no_projet_`) VALUES
("0299033703j", 1),
("11111111111", 1),
("22222222222", 1),
("88888888888", 1),
("44444444444", 2),
("55555555555", 2),
("987654321dd", 2),
("0299033703j", 3),
("33333333333", 4),
("66666666666", 4),
("77777777777", 4),
("987654321dd", 4),
("99999999999", 4);

-- --------------------------------------------------------

--
-- Structure de la table `tuteur`
--

CREATE TABLE IF NOT EXISTS `tuteur` (
  `id_tuteur` int(11) NOT NULL auto_increment,
  `nom_tuteur` varchar(42) NOT NULL,
  `pren_tuteur` varchar(42) NOT NULL,
  `fonction_tuteur` varchar(70) default NULL,
  PRIMARY KEY  (`id_tuteur`)
) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `tuteur`
--

INSERT INTO `tuteur` (`id_tuteur`, `nom_tuteur`, `pren_tuteur`, `fonction_tuteur`) VALUES
(1, "Beuter", "Anne", ''),
(2, "Rodrigues", "Jérôme", "Enseignant Chercheur"),
(3, "N'Kaoua", "Bernard", "Enseignant Chercheur"),
(4, "toto", "ami", "Chercheur");

-- --------------------------------------------------------

--
-- Structure de la table `univentr`
--

CREATE TABLE IF NOT EXISTS `univentr` (
  `id_univentr` int(11) NOT NULL auto_increment,
  `nom_univentr` varchar(100) character set latin1 NOT NULL,
  `adr_univentr` longtext character set latin1,
  `site_univentr` varchar(100) character set latin1 NOT NULL,
  `univ/entr(0/1)` tinyint(1),
  PRIMARY KEY  (`id_univentr`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `univentr`
--

INSERT INTO `univentr` (`id_univentr`, `nom_univentr`, `adr_univentr`, `site_univentr`, `univ/entr(0/1)`) VALUES
(1,'',null,'',0),
(3, "Université Bordeaux 2", NULL, "www.u-bordeaux2.fr", 0),
(2, "INRIA", NULL, "www.inria.fr", 1);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `encadrant`
--
ALTER TABLE `encadrant`
  ADD CONSTRAINT `encadrant_ibfk_1` FOREIGN KEY (`no_etablabo_`) REFERENCES `etablabo` (`no_etablabo`);

--
-- Contraintes pour la table `etablabo`
--
ALTER TABLE `etablabo`
  ADD CONSTRAINT `etablabo_ibfk_1` FOREIGN KEY (`id_univentr_`) REFERENCES `univentr` (`id_univentr`);

--
-- Contraintes pour la table `porter_sur`
--
ALTER TABLE `porter_sur`
  ADD CONSTRAINT `porter_sur_ibfk_1` FOREIGN KEY (`no_projet_`) REFERENCES `porter_sur` (`no_projet_`);

--
-- Contraintes pour la table `projet`
--
ALTER TABLE `projet`
  ADD CONSTRAINT `projet_ibfk_1` FOREIGN KEY (`id_encadrant_`) REFERENCES `encadrant` (`id_encadrant`);

--
-- Contraintes pour la table `suivre`
--
ALTER TABLE `suivre`
  ADD CONSTRAINT `suivre_ibfk_1` FOREIGN KEY (`no_projet_`) REFERENCES `projet` (`no_projet`),
  ADD CONSTRAINT `suivre_ibfk_2` FOREIGN KEY (`id_tuteur_`) REFERENCES `tuteur` (`id_tuteur`);

--
-- Contraintes pour la table `travailler`
--
ALTER TABLE `travailler`
  ADD CONSTRAINT `travailler_ibfk_1` FOREIGN KEY (`no_etud_`) REFERENCES `etudiant` (`no_etud`),
  ADD CONSTRAINT `travailler_ibfk_2` FOREIGN KEY (`no_projet_`) REFERENCES `projet` (`no_projet`);
