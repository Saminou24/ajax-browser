<?php
function status($menu)
{// ajoute une class CSS spécial au bouton correspondant à la page courante
	if (isset($_REQUEST['p'])==FALSE)
	{// aucune page demander = page d'acceuil
		if ($menu=='acceuil')
		{
			echo 'current ';
		}
	} else
	{// l'utilisateur à demander une page
		if ($menu==$_REQUEST['p'])
		{
			echo 'current ';
		}
	}
}

function include_page()
{// test si la page est un fichier valide, si oui on inclus sinon page par défault
	if (isset($_REQUEST['p'])==TRUE)
	{// on inclue le fichier passer en parametre
		$pages_valid = array(
			'acceuil' => 'Acceuil',
			'recherche' => 'Recherche de projet',
// 			'resultat' => 'Résultat(s) de recherche',
			'contact' => 'Contact'
		);

		if (array_key_exists($_REQUEST['p'], $pages_valid)==TRUE)
		{// on vérifie si la page demander existe bien
			$page['fichier'] = './_files/php/'.$_REQUEST['p'].'.php';
		} else
		{// on affiche la page d'acceuil par défaut
			$page['fichier'] = './_files/php/acceuil.php';
		}
		$page['titre'] = $pages_valid[$_REQUEST['p']];
		echo $titre;
	} else
	{// on affiche la page d'acceuil par défaut
		$page['fichier'] = './_files/php/acceuil.php';
	}
	return $page;
}

$page = include_page();
// var_dump($page);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" dir="ltr" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
	<meta http-equiv="Reply-to" content="?????????????????" />
	<meta http-equiv="Expires" content="never" />
	<meta http-equiv="Rating" content="general" />
	<meta http-equiv="Keywords" content="idc, Institut de Cognitique, cognitique, bordeaux, école d'ingénieur" />
	<meta http-equiv="ROBOTS" content="ALL, INDEX" />
	<meta http-equiv="Author" content="Delphine Graeff, Yassin Medoukali, Édouard Lopez" />
	<meta http-equiv="Revised" content="2008-12-08" />
	<meta http-equiv="Language" content="fr" />
	<meta name="revisit-after" content="1 week" />
	<link rel='stylesheet' type='text/css' href='./_files/css/style.css' id='style' />
	<link rel='icon' type='image/png' href='Bordeaux2.png' />
	<title><?php echo $page['titre']; ?> @ Projets idc</title>
</head>
<body>
	<div id='logo' title="Page d'acceuil">
		<a href='?p=acceuil'><img src='./_files/images/idc_logo_small.png' alt="Allez à la page d'aceuil"/></a>
		<a href='#content' class='h'>allez au contenu principal</a>
	</div>
	<?php require_once './_files/php/menu.php'; ?>
	<div id='content'>
		<?php require_once $page['fichier']; ?>
	</div>
	<?php include './_files/php/footer.php'; ?>
</body>
</html>